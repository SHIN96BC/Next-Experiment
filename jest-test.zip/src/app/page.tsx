import Image from 'next/image';
import TestComponent from '@Components/TestComponent';
import Link from 'next/link';
import LoginTypeExampleBtn from '@Components/button/LoginTypeExampleBtn';
import LogoutBtn from '@Components/button/LogoutBtn';
import CommonLinkBtn from '@Components/button/CommonLinkBtn';

export default function Home() {
  const r = '3';
  console.log(r);

  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <h1>Home</h1>
      <CommonLinkBtn url="/parallel">parallel page</CommonLinkBtn>
      <CommonLinkBtn url="/test" color="secondary">
        test page
      </CommonLinkBtn>
      <CommonLinkBtn url="/mypage">My page</CommonLinkBtn>
      <LoginTypeExampleBtn />
      <TestComponent />
    </main>
  );
}
