'use client';

import { useCallback } from 'react';
import Link from 'next/link';

export default function LoginTypeExampleBtn() {
  /**
   * 기본적으로 next의 router 이동이 /login 페이지로 발생하면 interception routes가 요청을 가로채서
   * interception routes로 설정해둔 (.login) 페이지로 이동합니다.
   * 그런데 강제로 일반 로그인 페이지로 보낼 수 있는 방법이 따로 제공되지 않아서 여러가지 방법을 직접 테스트했습니다.
   */

  const handleClick = useCallback(() => {
    // *interception routes를 우회하는 방법1(window.location.href로 이동)
    window.location.href = '/login';
  }, []);

  return (
    <>
      {/* interception routes를 활용한 팝업형태 로그인 페이지 */}
      <Link href="/login" passHref>
        login page(interception routes 팝업)
      </Link>
      <button type="button" onClick={handleClick}>
        Login Page(window.location.href로 이동)
      </button>
      {/* *interception routes를 우회하는 방법2(새탭 열기) */}
      <Link href="/login" target="_blank">
        Login Page(새탭 열기)
      </Link>
    </>
  );
}
