import { setupServer } from 'msw/node';
import handlers from '@Src/mocks/handlers';

export const mockServer = setupServer(...handlers);

export default undefined;
