import { FileServiceBase } from '@Src/services/FileServiceBase';
import FileServiceBaseImpl from '@Src/services/FileServiceBaseImpl';
import { CommonRes } from '@Src/services/commonModel';
import { FileUploadRes } from '@Src/services/file/model';

describe('FileServiceBaseImpl', () => {
  let fileServiceBase: FileServiceBase;

  beforeEach(() => {
    fileServiceBase = FileServiceBaseImpl.getInstance();
  });

  test('setToken test ', () => {
    if (fileServiceBase.setToken) {
      fileServiceBase.setToken('test1');
      expect(fileServiceBase.token).toEqual('test1');
    }
  });

  test('fileUpload error test', async () => {
    const formData = new FormData();

    // throw 테스트의 경우 expect 자체에 await를 걸어줘야함
    await expect(
      fileServiceBase.fileUpload<CommonRes<FileUploadRes>>(
        'http://localhost:8080/file/upload/error',
        formData
      )
    ).rejects.toThrow('Network response was not ok');
  });

  test('fileUpload network error test', async () => {
    const formData = new FormData();

    // throw 테스트의 경우 expect 자체에 await를 걸어줘야함
    await expect(
      fileServiceBase.fileUpload<CommonRes<FileUploadRes>>(
        'http://localhost:8080/file/upload/network_error',
        formData
      )
    ).rejects.toThrow('Failed to fetch');
  });

  test('fileUpload test', async () => {
    const formData = new FormData();
    expect(
      await fileServiceBase.fileUpload<CommonRes<FileUploadRes>>(
        'http://localhost:8080/file/upload',
        formData
      )
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });

  test('fileUpload and header test', async () => {
    const formData = new FormData();
    expect(
      await fileServiceBase.fileUpload<CommonRes<FileUploadRes>>(
        'http://localhost:8080/file/upload',
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      )
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });
});
