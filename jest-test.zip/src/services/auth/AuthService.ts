import { ServiceBase } from '@Src/services/ServiceBase';
import { AuthLoginReq, AuthLoginRes } from '@Src/services/auth/model';
import { CommonRes } from '@Src/services/commonModel';

class AuthService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(ServiceBase)에만 의존
   * @type {ServiceBase}
   * @private
   */
  private readonly service: ServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {ServiceBase} service
   */
  constructor(service: ServiceBase) {
    this.service = service;
  }

  /**
   * 로그인
   * @param {AuthLoginReq} data
   * @returns {Promise<CommonRes<AuthLoginRes>>}
   */
  login(data: AuthLoginReq) {
    return this.service.post<CommonRes<AuthLoginRes>, AuthLoginReq>(
      '/login',
      data
    );
  }

  /**
   * 로그아웃
   * @returns {Promise<CommonRes>}
   */
  logout() {
    return this.service.post<CommonRes>('/logout');
  }
}

export default AuthService;
