import { useMutation } from '@tanstack/react-query';
import queryOptions from '@Src/services/auth/queries';

export const useMutationLogin = () => useMutation(queryOptions.login());

export const useMutationLogout = () => useMutation(queryOptions.logout());
