import { ServiceBase } from '@Src/services/ServiceBase';
import ServiceBaseImpl from '@Src/services/ServiceBaseImpl';
import TestService from '@Src/services/test/TestService';

describe('Test Service', () => {
  let serviceBase: ServiceBase;

  beforeEach(() => {
    jest.clearAllMocks();
    serviceBase = new ServiceBaseImpl();
  });

  test('getTest test', async () => {
    const service = new TestService(serviceBase);
    expect(await service.getTest({ key: 'test1' })).toEqual({
      status: 200,
      ok: true,
      result: { name: 'test', email: 'test@test.com', phone: '000-0000-0000' },
    });
  });

  test('addTest test', async () => {
    const service = new TestService(serviceBase);
    expect(
      await service.addTest({
        key: '1234434',
        name: 'test',
        email: 'test@test.com',
        phone: '000-0000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });
});
