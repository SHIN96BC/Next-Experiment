import serviceContainer from '@Src/services/ServiceContainer';
import { render } from '@Src/jestUtils.test';
import { useSession } from 'next-auth/react';

describe('AuthProvider', () => {
  it('Should set the correct provider', async () => {
    const mockSetToken = jest.spyOn(serviceContainer, 'setToken'); // setToken을 spy로 만듭니다.

    // useSession mock
    (useSession as jest.Mock).mockImplementation(() => {
      return {
        data: {
          accessToken: 'testToken@@@!@#!@#!@#!@#$%',
          user: {
            email: 'test@test.com',
            id: '123432343',
            name: '홍길동',
          },
          status: 'authenticated',
        },
      };
    });

    await render(<div>Child Component</div>);

    // serviceContainer.setToken이 호출되었는지 확인
    expect(mockSetToken).toHaveBeenLastCalledWith('testToken@@@!@#!@#!@#!@#$%');
  });
});
