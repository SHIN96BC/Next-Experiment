import CustomSessionStorage from '@Src/utils/storages/CustomSessionStorage';

describe('CustomSessionStorage', () => {
  beforeEach(() => {
    localStorage.clear();
    jest.clearAllMocks();
  });

  test('Empty value test set method', () => {
    const key = 'key';
    CustomSessionStorage.set(key, undefined);
    expect(CustomSessionStorage.get(key)).not.toBeDefined();
  });

  test('test set method', () => {
    const key = 'key';
    CustomSessionStorage.set(key, { name: 'name', value: 'value' });
    expect(CustomSessionStorage.get(key)).toEqual({
      name: 'name',
      value: 'value',
    });
  });

  test('test get method', () => {
    const key = 'key';

    CustomSessionStorage.set(key, { name: 'name', value: 'value' });
    expect(CustomSessionStorage.get(key)).toEqual({
      name: 'name',
      value: 'value',
    });
  });

  test('exception test get method', () => {
    const key = 'key';

    CustomSessionStorage.set(key, { name: 'name', value: 'value' });

    // CustomLocalStorage.get에서 예외를 발생시키도록 mock
    jest.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
      throw new Error('CustomLocalStorage.get');
    });

    expect(CustomSessionStorage.get(key)).not.toBeDefined();
  });

  test('test remove method', () => {
    const key = 'key';

    CustomSessionStorage.set(key, { name: 'name', value: 'value' });
    CustomSessionStorage.remove(key);

    expect(CustomSessionStorage.get(key)).not.toBeDefined();
  });

  test('test clear method', () => {
    const key1 = 'key1';
    const key2 = 'key2';

    CustomSessionStorage.set(key1, { name: 'name1', value: 'value1' });
    CustomSessionStorage.set(key2, { name: 'name2', value: 'value2' });
    CustomSessionStorage.clear();

    expect(CustomSessionStorage.get(key1)).not.toBeDefined();
    expect(CustomSessionStorage.get(key2)).not.toBeDefined();
  });
});
