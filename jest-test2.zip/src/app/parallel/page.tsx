import Link from 'next/link';
import ParallelChangeForm from '@Src/features/parallel/ParallelChangeForm';

async function getData() {
  await new Promise((resolve) => {
    setTimeout(resolve, 1000);
  });

  return { result: 'result1', status: 200, isOk: true };
}

export default async function ParallelPage() {
  const data = await getData();

  return (
    <div className="h-full bg-emerald-500">
      <div>Parallel Page</div>
      <div>{data.result}</div>
      <Link href="/login" passHref>
        Login
      </Link>
      <ParallelChangeForm />
    </div>
  );
}
