import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface MenusState {
  openList: string[];
}

const initialState: MenusState = {
  openList: [],
};

const menusSlice = createSlice({
  name: 'menus',
  initialState,
  reducers: {
    changeOpenMenusState(state: MenusState, action: PayloadAction<string>) {
      const newState = { ...state };

      if (newState.openList.find((menu) => menu === action.payload)) {
        newState.openList = newState.openList.filter(
          (menu) => menu !== action.payload
        );
      } else {
        newState.openList = [...newState.openList, action.payload];
      }

      return newState;
    },
  },
});

export const { changeOpenMenusState } = menusSlice.actions;

export default menusSlice.reducer;
