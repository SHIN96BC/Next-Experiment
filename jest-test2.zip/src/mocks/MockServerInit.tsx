'use client';

import { ReactNode, useEffect, useState } from 'react';

const isMockingMode = process.env.NEXT_PUBLIC_API_MOCKING === 'enabled';

export default function MockServerInit({ children }: { children: ReactNode }) {
  const [hasWorkerStarted, setWorkerStarted] = useState(false);

  const handleStartMockWorker = async () => {
    /**
     * 반드시 await로 기다려주지 않으면 msw 라이브러리에서 런타임 오류 발생(ex: 새탭 열기 할 때 등)
     * - Uncaught TypeError: Cannot read properties of undefined (reading 'url')
     */
    if (typeof window !== 'undefined') {
      // eslint-disable-next-line @typescript-eslint/no-var-requires,global-require
      const { mockWorker } = await import('@Src/mocks/browser');
      mockWorker.start({ onUnhandledRequest: 'bypass' }).then(() => {
        setWorkerStarted(true);
      });
      console.info('mockWorker listening on port 3002');
    }
  };

  useEffect(() => {
    // msw test browser server start
    if (isMockingMode) {
      handleStartMockWorker();
    }
  }, []);

  if (!isMockingMode) {
    return children;
  }

  return hasWorkerStarted ? children : null;
}
