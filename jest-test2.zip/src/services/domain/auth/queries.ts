import { AuthLoginReq, AuthLoginRes } from '@Src/services/domain/auth/model';
import { CommonRes } from '@Src/services/commonModel';
import AuthService from '@Src/services/domain/auth/AuthService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

const queryKeys = {};

const queryOptions = {
  login: () => ({
    mutationFn: (data: AuthLoginReq) =>
      serviceContainer
        .resolveService<AuthService>(SERVICE_NAME.AUTH)
        .login<CommonRes<AuthLoginRes>, AuthLoginReq>(data),
  }),
  logout: () => ({
    mutationFn: () =>
      serviceContainer
        .resolveService<AuthService>(SERVICE_NAME.AUTH)
        .logout<CommonRes>(),
  }),
};

export default queryOptions;
