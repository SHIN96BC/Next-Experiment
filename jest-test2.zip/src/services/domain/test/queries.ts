import {
  TestFindAllReq,
  TestFindAllRes,
  TestSaveReq,
  TestSaveRes,
} from '@Src/services/domain/test/model';
import { CommonRes } from '@Src/services/commonModel';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findAll: readonly [string]}}
 */
const queryKeys = {
  findAll: ['test'] as const,
};

/**
 * React Query Options Object
 * @type {{save: () => {mutationFn: (data: TestSaveReq) => Promise<TestSaveRes>}, findAll: (params: TestFindAllReq) => {queryKey: readonly [string], queryFn: () => Promise<TestFindAllRes>}}}
 */
const queryOptions = {
  findAll: (params: TestFindAllReq) => ({
    queryKey: queryKeys.findAll,
    queryFn: () =>
      serviceContainer
        .get<TestService>(SERVICE_NAME.TEST)
        .getTest<CommonRes<TestFindAllRes>, TestFindAllReq>(params),
  }),
  save: () => ({
    mutationFn: (data: TestSaveReq) =>
      serviceContainer
        .get<TestService>(SERVICE_NAME.TEST)
        .addTest<CommonRes<TestSaveRes>, TestSaveReq>(data),
  }),
};

export default queryOptions;
