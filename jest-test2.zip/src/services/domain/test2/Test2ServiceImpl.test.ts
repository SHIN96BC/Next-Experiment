import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import CommonServiceBaseImpl from '@Src/services/base/common/CommonServiceBaseImpl';
import Test2ServiceImpl from '@Src/services/domain/test2/Test2ServiceImpl';

describe('Test2 Service', () => {
  let serviceBase: CommonServiceBase;

  beforeEach(() => {
    jest.clearAllMocks();
    serviceBase = new CommonServiceBaseImpl();
  });

  test('getTest2 test', async () => {
    const service = new Test2ServiceImpl(serviceBase);
    expect(await service.getTest2({ key: 'test1' })).toEqual({
      status: 200,
      ok: true,
      result: { name: 'test', email: 'test@test.com', phone: '000-0000-0000' },
    });
  });

  test('addTest2 test', async () => {
    const service = new Test2ServiceImpl(serviceBase);
    expect(
      await service.addTest2({
        key: '1234434',
        name: 'test',
        email: 'test@test.com',
        phone: '000-0000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });
});
