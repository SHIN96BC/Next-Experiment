export interface Test2FindAllReq {
  key: string;
}

export interface Test2FindAllRes {
  name: string;
  email: string;
  phone: string;
}

export interface Test2SaveReq {
  key: string;
  name: string;
  email: string;
  phone: string;
}

export interface Test2SaveRes {
  isOk: boolean;
}
