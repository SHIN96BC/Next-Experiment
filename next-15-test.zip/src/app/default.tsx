export default function RootDefault() {
  return null;
}
