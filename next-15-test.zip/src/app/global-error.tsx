'use client';

import CommonBtn from '@Components/button/CommonBtn';
import CommonLinkBtn from '@Components/button/CommonLinkBtn';

interface Props {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function GlobalError({ error, reset }: Props) {
  return (
    // eslint-disable-next-line jsx-a11y/html-has-lang
    <html>
      <body>
        <main className="w-screen h-screen flex items-center justify-center">
          <div>
            <div>
              <h1 className="text-center">Something went wrong!</h1>
            </div>

            <div className="flex items-center justify-center pt-5">
              <CommonBtn onClick={() => reset()}>Try again</CommonBtn>
            </div>

            <div className="flex items-center justify-center pt-3">
              <CommonLinkBtn url="/">Go to Home</CommonLinkBtn>
            </div>
          </div>
        </main>
      </body>
    </html>
  );
}
