import AuthGuard from '@Src/utils/auth/AuthGuard';
import { ReactNode } from 'react';

export default function MypageLayout({ children }: { children: ReactNode }) {
  console.log('mypageLayout');
  return <AuthGuard>{children}</AuthGuard>;
}
