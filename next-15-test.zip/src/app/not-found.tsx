export default function RootNotFound() {
  return <></>;
}
