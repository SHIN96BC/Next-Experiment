import TestComponent from '@Components/TestComponent';
import LoginTypeExampleBtn from '@Components/button/LoginTypeExampleBtn';
import CommonLinkBtn from '@Components/button/CommonLinkBtn';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <h1>Home</h1>
      <CommonLinkBtn url="/parallel">parallel page</CommonLinkBtn>
      <CommonLinkBtn url="/test" color="secondary">
        test page
      </CommonLinkBtn>
      <CommonLinkBtn url="/mypage">My page</CommonLinkBtn>
      <CommonLinkBtn url="/search">Search</CommonLinkBtn>
      <LoginTypeExampleBtn />
      <TestComponent />
    </main>
  );
}
