export default function Parallel1Loading() {
  return <div>Loading...</div>;
}
