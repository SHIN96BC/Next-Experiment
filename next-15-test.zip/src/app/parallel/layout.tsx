import { ReactNode } from 'react';

export default function ParallelLayout({
  children,
  parallel1,
  parallel2,
}: {
  children: ReactNode;
  parallel1: ReactNode;
  parallel2: ReactNode;
}) {
  return (
    <div className="grid grid-rows-2 grid-cols-2 h-screen">
      <div className="col-span-2 row-span-1">{children}</div>

      <div className="col-span-1">{parallel1}</div>
      <div className="col-span-1">{parallel2}</div>
    </div>
  );
}
