import queryOptions from '@Src/services/domain/test/queries';
import { getDehydratedQuery, Hydrate } from '@Src/services/react-query';
import UseTransitionTest from '@Src/features/test/UseTransitionTest';

const getTestData = async () => {
  const { queryKey, queryFn } = queryOptions.findTest({});
  // const result = query?.state?.data?.result;

  return await getDehydratedQuery({ queryKey, queryFn });
};

export default async function TestPage() {
  const query = await getTestData();

  return (
    <div className="w-screen h-screen px-5">
      <div>Test Page</div>

      <Hydrate state={{ queries: query ? [query] : [] }}>
        <UseTransitionTest />
      </Hydrate>
    </div>
  );
}
