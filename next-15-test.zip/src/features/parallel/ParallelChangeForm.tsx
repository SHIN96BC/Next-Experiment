'use client';

import CommonBtn from '@Components/button/CommonBtn';
import { useCallback, useState } from 'react';

export default function ParallelChangeForm() {
  const [open, setOpen] = useState<boolean>(false);

  const handleChange = useCallback(() => {
    setOpen((flag) => !flag);
  }, [setOpen]);

  return (
    <div>
      <CommonBtn onClick={handleChange}>Change</CommonBtn>
      <div>{open ? 'open' : 'close'}</div>
    </div>
  );
}
