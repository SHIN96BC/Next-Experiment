'use client';

import { useEffect, useState, useTransition } from 'react';
import { useFindTestQuery } from '@Src/services/domain/test/useTestService';
import { redirect } from 'next/navigation';
import mutationOptions from '@Src/services/domain/test/mutations';
import CommonBtn from '@Components/button/CommonBtn';

export default function UseTransitionTest() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [isPending, startTransition] = useTransition();

  const { data } = useFindTestQuery({});

  console.log('data = ', data);
  console.log('isPending = ', isPending);

  const handleSubmit = () => {
    startTransition(async () => {
      const error = await mutationOptions
        .registerTest()
        .mutationFn({ name, email, phone });
      if (!error.ok) {
        setError(error.message);
        return;
      }
      redirect('/');
    });
  };

  useEffect(() => {
    if (data?.result) {
      if (data.result?.name) {
        setName(data.result.name);
      }
      if (data.result?.email) {
        setEmail(data.result.email);
      }
      if (data.result?.phone) {
        setPhone(data.result.phone);
      }
    }
  }, [data]);

  return (
    <section>
      <div>
        <p>Name</p>
        <input
          className="border border-blue-400 focus:border-blue-600 px-3 py-2 rounded-md"
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
      </div>
      <div>
        <p>Email</p>
        <input
          className="border border-blue-400 focus:border-blue-600 px-3 py-2 rounded-md"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
        />
      </div>
      <div>
        <p>Phone</p>
        <input
          className="border border-blue-400 focus:border-blue-600 px-3 py-2 rounded-md"
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
        />
      </div>
      <CommonBtn onClick={handleSubmit} disabled={isPending}>
        Register
      </CommonBtn>
      {error && <p>{error}</p>}
    </section>
  );
}
