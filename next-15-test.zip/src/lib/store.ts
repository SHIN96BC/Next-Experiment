import { combineReducers, configureStore } from '@reduxjs/toolkit';
import testSlice from '@Src/lib/features/test/testSlice';
import authSlice from '@Src/lib/features/auth/authSlice';
import commonAlertSlice from '@Src/lib/common/alert/commonAlertSlice';
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import menusSlice from '@Src/lib/common/menus/menusSlice';

const reducer = combineReducers({
  auth: authSlice,
  tests: testSlice,
  commonAlert: commonAlertSlice,
  menus: menusSlice,
});

const persistConfig = {
  key: 'rootPersist',
  storage,
  whitelist: ['menus'],
};

const persistedReducer = persistReducer(persistConfig, reducer);

export const makeStore = () => {
  return configureStore({
    // reducer: {
    //   auth: authSlice,
    //   tests: testSlice,
    //   commonAlert: commonAlertSlice,
    // },
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware) =>
      // state에 function을 사용하기 위해 선언
      getDefaultMiddleware({
        serializableCheck: false,
      }),
  });
};

// Infer the type of makeStore
export type AppStore = ReturnType<typeof makeStore>;
// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<AppStore['getState']>;
export type AppDispatch = AppStore['dispatch'];
