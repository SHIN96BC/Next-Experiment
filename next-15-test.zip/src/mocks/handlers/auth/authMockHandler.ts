// eslint-disable-next-line import/no-extraneous-dependencies
import { http, HttpResponse } from 'msw';
import { host } from '@Src/mocks/mockConfig';

const authMockHandler = [
  http.post(`${host}/login`, async ({ request }) => {
    console.log('msw -> login');
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: {
        user: {
          id: '123432343',
          name: '홍길동',
          email: 'test@test.com',
        },
        access_token: 'testToken@@@!@#!@#!@#!@#$%',
        refresh_token: 'refreshToken!@#!@$@%@#$!@',
      },
    });
  }),
  http.post(`${host}/login_error`, async ({ request }) => {
    return HttpResponse.error();
  }),
  http.post(`${host}/logout`, async ({ request }) => {
    return HttpResponse.json({ status: 200, ok: true });
  }),
];

export default authMockHandler;
