import authMockHandler from '@Src/mocks/handlers/auth/authMockHandler';
import testMockHandler from '@Src/mocks/handlers/test/testMockHandler';
import fileMockHandler from '@Src/mocks/handlers/file/fileMockHandler';
import test2MockHandler from '@Src/mocks/handlers/test2/test2MockHandler';

export const addDelay = async (response: any, delay = 1000) => {
  await new Promise((resolve) => setTimeout(resolve, delay)); // delay 밀리초 대기
  return response;
};

export default [
  ...authMockHandler,
  ...testMockHandler,
  ...fileMockHandler,
  ...test2MockHandler,
];
