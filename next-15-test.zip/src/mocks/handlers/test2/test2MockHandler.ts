// eslint-disable-next-line import/no-extraneous-dependencies
import { http, HttpResponse } from 'msw';
import { host } from '@Src/mocks/mockConfig';

const test2MockHandler = [
  http.get(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: { name: 'test', email: 'test@test.com', phone: '000-0000-0000' },
    });
  }),
  http.delete(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  }),
  http.head(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
    });
  }),

  http.options(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
    });
  }),
  http.post(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  }),
  http.put(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  }),
  http.patch(`${host}/test2`, async ({ request }) => {
    return HttpResponse.json({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  }),

  http.get(`${host}/test2/error`, async ({ request }) => {
    return new HttpResponse('server error', { status: 500 });
  }),
  http.post(`${host}/test2/error`, async ({ request }) => {
    return new HttpResponse('server error', { status: 500 });
  }),
  http.get(`${host}/test2/network_error`, async ({ request }) => {
    return HttpResponse.error();
  }),
  http.post(`${host}/test2/network_error`, async ({ request }) => {
    return HttpResponse.error();
  }),
];

export default test2MockHandler;
