export interface TestGetReq {
  key?: string;
}

export interface TestGetRes {
  name: string;
  email: string;
  phone: string;
}

export interface TestPostReq {
  name: string;
  email: string;
  phone: string;
}

export interface TestPostRes {
  isOk: boolean;
}
