import { TestPostReq } from '@Src/services/domain/test/model';
import { serviceContainer } from '@Src/services/config';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';

const mutationKeys = {
  registerTest: ['registerTest'] as const,
};

const mutationOptions = {
  registerTest: () => ({
    mutationKey: mutationKeys.registerTest,
    mutationFn: (data: TestPostReq) =>
      serviceContainer.get<TestService>(SERVICE_NAME.TEST).postTest(data),
  }),
};

export default mutationOptions;
