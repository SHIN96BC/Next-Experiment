import { useMutation, useQuery } from '@tanstack/react-query';
import queryOptions from '@Src/services/domain/test/queries';
import { TestGetReq } from '@Src/services/domain/test/model';
import { useSession } from 'next-auth/react';
import mutationOptions from '@Src/services/domain/test/mutations';

/**
 * Find All Test
 * @param {TestGetReq} params
 * @param lazy
 * @returns {UseQueryResult<TestGetRes, DefaultError>}
 */
export const useFindTestQuery = (params: TestGetReq, lazy?: boolean) =>
  useQuery({
    ...queryOptions.findTest(params),
    enabled: !lazy,
  });

/**
 * Save Test
 * @returns {UseMutationResult<CommonRes<TestPostRes>, DefaultError, TestPostReq, unknown>}
 */
export const useRegisterTestMutation = () =>
  useMutation(mutationOptions.registerTest());
