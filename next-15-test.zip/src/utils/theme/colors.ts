export type ThemeColorsType =
  | 'normal'
  | 'primary'
  | 'secondary'
  | 'disabled'
  | 'success'
  | 'warning'
  | 'danger'
  | 'error';
