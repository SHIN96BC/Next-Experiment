import type { Config } from 'tailwindcss';

const config: Config = {
  purge: {
    // tailwind가 특정 사용하지 않는 클래스명을 삭제하지 않도록 설정
    content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
    options: {
      safelist: [/bg-/, /hover:bg-/],
    },
  },
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/features/**/*.{js,ts,jsx,tsx,mdx}',
    './src/layouts/**/*.{js,ts,jsx,tsx,mdx}',
    './src/modals/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic':
          'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
      },
      colors: {
        primary: {
          light: '#c9c4f9',
          DEFAULT: '#9e95f5',
          dark: '#7367f0',
        },
        secondary: {
          light: '#69c1ff',
          DEFAULT: '#36abff',
          dark: '#0396ff',
        },
      },
    },
  },
  plugins: [],
};
export default config;
