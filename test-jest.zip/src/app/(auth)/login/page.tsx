import LoginForm from '@Src/features/login/LoginForm';

export default function LoginPage() {
  return (
    <div>
      <div>Login Page</div>
      <LoginForm />
    </div>
  );
}
