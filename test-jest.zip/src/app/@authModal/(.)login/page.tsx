import CommonModal from '@Src/modals/CommonModal';
import LoginForm from '@Src/features/login/LoginForm';

export default function AuthLoginPage() {
  return (
    <CommonModal maxWidth={500} maxHeight={500}>
      <LoginForm />
    </CommonModal>
  );
}
