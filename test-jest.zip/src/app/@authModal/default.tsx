export default function AuthLoginDefault() {
  return null;
}
