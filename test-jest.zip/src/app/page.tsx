import Image from 'next/image';
import TestComponent from '@Components/TestComponent';
import Link from 'next/link';
import LoginPageBtn from '@Components/button/LoginPageBtn';

export default function Home() {
  const r = '3';
  console.log(r);

  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <h1>Home</h1>
      <Link href="/parallel">parallel page</Link>
      <Link href="/test">test page</Link>
      <Link href="/login" passHref>
        login page(interception routes)
      </Link>
      <LoginPageBtn />
      <TestComponent />
    </main>
  );
}
