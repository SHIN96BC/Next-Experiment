export default function Parallel2Loading() {
  return <div>Loading...</div>;
}
