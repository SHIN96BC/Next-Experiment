export default function TestPage() {
  return (
    <div className="w-screen h-screen">
      <div>Test Page</div>
    </div>
  );
}
