'use client';

import { useCallback } from 'react';
import Link from 'next/link';

export default function LoginPageBtn() {
  const handleClick = useCallback(() => {
    // *interception routes를 우회하는 방법1(강제 새로고침)
    window.location.href = '/login';
  }, []);

  return (
    <>
      <button type="button" onClick={handleClick}>
        Login Page(강제 새로고침)
      </button>
      {/* *interception routes를 우회하는 방법2(새탭 열기) */}
      <Link href="/login" target="_blank">
        Login Page(새탭 열기)
      </Link>
    </>
  );
}
