import CommonInput from '@Components/input/CommonInput';

export default function LoginForm() {
  return (
    <div>
      <div>
        <div>ID</div>
        <CommonInput />
      </div>
      <div>
        <div>PW</div>
        <CommonInput />
      </div>
    </div>
  );
}
