export default function CommonHeader() {
  return (
    <div>
      <div />
    </div>
  );
}
