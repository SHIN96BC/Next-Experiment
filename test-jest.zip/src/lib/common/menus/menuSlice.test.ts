import reducer, {
  changeOpenMenusState,
} from '@Src/lib/common/menus/menusSlice';

test('should return the initial state', () => {
  expect(reducer(undefined, { type: 'unknown' })).toEqual({
    openList: [],
  });
});

test('should test changeOpenMenusState add and remove', () => {
  const addResult = reducer(undefined, changeOpenMenusState('menu1'));

  expect(addResult.openList).toEqual(['menu1']);

  const removeResult = reducer(addResult, changeOpenMenusState('menu1'));

  expect(removeResult.openList).toEqual([]);
});
