import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface AuthState {
  name: string;
  accessToken: string;
}

const initialState = {
  name: '',
  accessToken: '',
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setAuth(state: AuthState, action: PayloadAction<AuthState>) {
      const newState = { ...state };
      newState.name = action.payload.name;
      newState.accessToken = action.payload.accessToken;

      return newState;
    },
    resetAuth() {
      return { name: '', accessToken: '' };
    },
  },
});

export const { setAuth, resetAuth } = authSlice.actions;

export default authSlice.reducer;
