import serviceContainer from '@Src/services/ServiceContainer';
import TestServiceImpl from '@Src/services/domain/test/TestServiceImpl';
import AuthServiceImpl from '@Src/services/domain/auth/AuthServiceImpl';

describe('ServiceContainer', () => {
  test('should register and resolve service correctly', () => {
    const testService =
      serviceContainer.resolveService<TestServiceImpl>('testService');
    const authService =
      serviceContainer.resolveService<AuthServiceImpl>('authService');

    expect(testService).toBeInstanceOf(TestServiceImpl);
    expect(authService).toBeInstanceOf(AuthServiceImpl);
  });

  test('should register and resolve service correctly', () => {
    const testService =
      serviceContainer.resolveService<TestServiceImpl>('testService');
    const authService =
      serviceContainer.resolveService<AuthServiceImpl>('authService');

    expect(testService).toBeInstanceOf(TestServiceImpl);
    expect(authService).toBeInstanceOf(AuthServiceImpl);
  });

  test('should resolve service is not found', () => {
    const serviceName = 'testService2';
    // toThrow 를 테스트는 expect 첫번째 인자를 함수로 줘야함
    expect(() => {
      serviceContainer.resolveService(serviceName);
    }).toThrow(`Service ${serviceName} not found`);
  });

  test('should set and clear token correctly', async () => {
    const mockService = {
      setToken: jest.fn(),
    };

    serviceContainer.registerServiceBase('mockService', mockService);

    await serviceContainer.setToken('test-token');
    expect(mockService.setToken).toHaveBeenCalledWith('test-token');

    await serviceContainer.clearToken();
    expect(mockService.setToken).toHaveBeenCalledWith(null);
  });
});
