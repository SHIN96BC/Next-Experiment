import { FileInstance } from '@Src/services/base/CommonServiceBase';

export interface FileServiceBase {
  file?: FileInstance;
  token?: string;
  setToken?: (token: string) => void;
  fileUpload: <R>(
    url: string,
    data: FormData,
    config?: RequestInit
  ) => Promise<R>;
}
