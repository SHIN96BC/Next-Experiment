export default interface AuthService {
  login<R, A>(data: A): Promise<R>;
  logout<R>(): Promise<R>;
}
