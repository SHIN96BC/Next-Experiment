import { CommonServiceBase } from '@Src/services/base/CommonServiceBase';
import AuthService from '@Src/services/domain/auth/AuthService';

class AuthServiceImpl implements AuthService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly service: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} service
   */
  constructor(service: CommonServiceBase) {
    this.service = service;
  }

  /**
   * 로그인
   * @param {A} data
   * @returns {Promise<R>}
   */
  login<R, A>(data: A): Promise<R> {
    return this.service.post<R, A>('/login', data);
  }

  /**
   * 로그아웃
   * @returns {Promise<R>}
   */
  logout<R>(): Promise<R> {
    return this.service.post<R>('/logout');
  }
}

export default AuthServiceImpl;
