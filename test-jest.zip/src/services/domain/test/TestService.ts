export default interface TestService {
  getTest<R, A>(params: A): Promise<R>;
  addTest<R, A>(data: A): Promise<R>;
}
