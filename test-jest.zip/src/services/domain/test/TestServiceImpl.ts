import { CommonServiceBase } from '@Src/services/base/CommonServiceBase';
import TestService from '@Src/services/domain/test/TestService';

class TestServiceImpl implements TestService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly service: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} service
   */
  constructor(service: CommonServiceBase) {
    this.service = service;
  }

  /**
   * 테스트 전체 조회
   * @param {A} params
   * @returns {Promise<R>}
   */
  getTest<R, A>(params: A): Promise<R> {
    return this.service.get<R, A>('/test', params);
  }

  /**
   * 테스트 등록
   * @param {A} data
   * @returns {Promise<R>}
   */
  addTest<R, A>(data: A): Promise<R> {
    return this.service.post<R, A>('/test', data);
  }
}

export default TestServiceImpl;

// const testService = new TestServiceImpl();
//
// export default testService;
