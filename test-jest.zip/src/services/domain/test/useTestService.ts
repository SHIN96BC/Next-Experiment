import { useMutation, useQuery } from '@tanstack/react-query';
import queryOptions from '@Src/services/domain/test/queries';
import { TestFindAllReq } from '@Src/services/domain/test/model';
import { useSession } from 'next-auth/react';

/**
 * Find All Test
 * @param {TestFindAllReq} params
 * @returns {UseQueryResult<TestFindAllRes, DefaultError>}
 */
export const useQueryFindAllTest = (params: TestFindAllReq) => {
  const session = useSession();

  return useQuery({
    ...queryOptions.findAll(params),
    enabled: !!session?.data?.accessToken,
  });
};

/**
 * Save Test
 * @returns {UseMutationResult<CommonRes<TestSaveRes>, DefaultError, TestSaveReq, unknown>}
 */
export const useMutationSaveTest = () => useMutation(queryOptions.save());
