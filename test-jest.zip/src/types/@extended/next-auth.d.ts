import { DefaultSession } from 'next-auth';

declare module 'next-auth' {
  interface JWT {
    idToken?: string;
  }
  interface Session {
    accessToken: string;
    user: {
      id: string;
    } & DefaultSession['user'];
  }
  interface Profile {
    id: string;
  }
}
