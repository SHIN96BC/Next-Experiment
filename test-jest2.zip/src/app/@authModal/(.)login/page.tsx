import InterceptionModal from '@Src/modals/InterceptionModal';
import LoginForm from '@Src/features/login/LoginForm';

export default function AuthModalLoginPage() {
  return (
    <InterceptionModal maxWidth={500} maxHeight={500}>
      <LoginForm isInterceptionPage />
    </InterceptionModal>
  );
}
