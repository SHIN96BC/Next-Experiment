export default function MypagePage() {
  return <div>마이페이지</div>;
}
