async function getData() {
  await new Promise((resolve) => {
    setTimeout(resolve, 2000);
  });

  return { result: 'result2', status: 200, isOk: true };
}

export default async function Parallel1Page() {
  const data = await getData();

  return (
    <div className="h-full bg-blue-500">
      <div>Parallel 1</div>
      <div>{data.result}</div>
    </div>
  );
}
