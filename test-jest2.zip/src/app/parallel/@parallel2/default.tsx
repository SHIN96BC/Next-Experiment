export default function Parallel2DefaultPage() {
  return null;
}
