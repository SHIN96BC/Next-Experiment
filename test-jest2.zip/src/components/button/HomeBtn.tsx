import Link from 'next/link';

export default function HomeBtn() {
  return <Link href="/">Home</Link>;
}
