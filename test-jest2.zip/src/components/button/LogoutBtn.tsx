'use client';

import { useCallback } from 'react';
import { signOut } from 'next-auth/react';

export default function LogoutBtn() {
  // const router = useRouter();

  const handleLogout = useCallback(() => {
    // mutate();
    signOut({ redirect: true, callbackUrl: '/' });
  }, []);

  return (
    <button type="button" onClick={handleLogout}>
      Logout
    </button>
  );
}
