'use client';

import CustomBtn from '@Components/button/CommonBtn';
import { useCallback, useState } from 'react';

export default function ParallelChangeForm() {
  const [open, setOpen] = useState<boolean>(false);

  const handleChange = useCallback(() => {
    setOpen((flag) => !flag);
  }, [setOpen]);

  return (
    <div>
      <CustomBtn onClick={handleChange}>Change</CustomBtn>
      <div>{open ? 'open' : 'close'}</div>
    </div>
  );
}
