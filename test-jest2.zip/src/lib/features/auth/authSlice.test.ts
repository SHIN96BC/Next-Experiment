import reducer, { setAuth, resetAuth } from '@Src/lib/features/auth/authSlice';

test('should return the initial state', () => {
  expect(reducer(undefined, { type: 'unknown' })).toEqual({
    name: '',
    accessToken: '',
  });
});

test('should test setAuth', () => {
  expect(
    reducer(
      undefined,
      setAuth({ name: 'user1', accessToken: '@@@#!SDFSDFdsfsdfdsfdf' })
    )
  ).toEqual({
    name: 'user1',
    accessToken: '@@@#!SDFSDFdsfsdfdsfdf',
  });
});

test('should test setAuth', () => {
  expect(reducer(undefined, resetAuth())).toEqual({
    name: '',
    accessToken: '',
  });
});
