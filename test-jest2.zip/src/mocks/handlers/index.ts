import authMockHandler from '@Src/mocks/handlers/auth/authMockHandler';
import testMockHandler from '@Src/mocks/handlers/test/testMockHandler';
import fileMockHandler from '@Src/mocks/handlers/file/fileMockHandler';
import test2MockHandler from '@Src/mocks/handlers/test2/test2MockHandler';

export default [
  ...authMockHandler,
  ...testMockHandler,
  ...fileMockHandler,
  ...test2MockHandler,
];
