import { render, waitFor, screen, fireEvent } from '@Src/jestUtils.test';
import { createPortal } from 'react-dom';
import InterceptionModal from '@Src/modals/InterceptionModal';
import { useRouter } from 'next/navigation';

describe('InterceptionModal', () => {
  let mockRouterBack: jest.Mock;

  beforeEach(() => {
    // dialog 기능 세팅
    HTMLDialogElement.prototype.showModal = jest.fn(function mock(
      this: HTMLDialogElement
    ) {
      this.open = true;
    });

    jest
      .spyOn(HTMLDialogElement.prototype, 'showModal')
      .mockImplementation(function (this: HTMLDialogElement) {
        // dialog의 showModal이 호출되면 open 속성에 true 부여
        this.setAttribute('open', 'true');
      });

    // useRouter의 back 함수를 mock으로 만듦
    mockRouterBack = jest.fn();
    (useRouter as jest.Mock).mockReturnValue({ back: mockRouterBack });

    // createPortal이 실제로 호출되면 해당 요소를 modal-root에 넣도록 설정
    (createPortal as jest.Mock).mockImplementation((element, target) => {
      return element;
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders modal in #modal-root using createPortal and shows modal when mounted', async () => {
    await render(<InterceptionModal>Test content</InterceptionModal>);

    // 실제 createPortal을 mock하여 모달이 modal-root에 렌더링되었는지 확인
    const modalRoot = document.getElementById('modal-root')!;
    expect(modalRoot).toBeInTheDocument();

    // dialog 요소에서 showModal이 호출되었는지 확인
    expect(HTMLDialogElement.prototype.showModal).toHaveBeenCalled();
    // dialog의 open 상태가 true로 변경되었는지 확인
    const dialogElement = screen.getByRole('dialog');
    expect(dialogElement).toHaveAttribute('open', 'true');
  });

  it('applies maxWidth and maxHeight correctly', async () => {
    await render(
      <InterceptionModal maxWidth={600} maxHeight={400}>
        Test content
      </InterceptionModal>
    );

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveClass('max-w-[600px]');
    expect(dialog).toHaveClass('max-h-[400px]');
  });

  it('applies string maxWidth and maxHeight correctly', async () => {
    await render(
      <InterceptionModal maxWidth="50%" maxHeight="75%">
        Test content
      </InterceptionModal>
    );

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveClass('max-w-[50%]');
    expect(dialog).toHaveClass('max-h-[75%]');
  });

  it('calls router.back when closed', async () => {
    await render(<InterceptionModal>Test content</InterceptionModal>);

    // 닫기 버튼 클릭
    fireEvent.click(screen.getByRole('button'));

    // router.back이 호출되었는지 확인
    expect(mockRouterBack).toHaveBeenCalled();
  });
});
