import {
  AuthLoginReq,
  AuthLoginRes,
  AuthLogoutRes,
} from '@Src/services/domain/auth/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface AuthService {
  login(data: AuthLoginReq): Promise<CommonRes<AuthLoginRes>>;
  logout(): Promise<CommonRes>;
}
