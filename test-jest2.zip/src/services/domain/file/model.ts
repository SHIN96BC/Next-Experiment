export interface FileUploadRes {
  isOk: boolean;
}
