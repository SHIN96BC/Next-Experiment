import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import TestService from '@Src/services/domain/test/TestService';
import {
  TestFindAllReq,
  TestFindAllRes,
  TestSaveReq,
  TestSaveRes,
} from '@Src/services/domain/test/model';
import { CommonRes } from '@Src/services/commonModel';

class TestServiceImpl implements TestService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly base: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} base
   */
  constructor(base: CommonServiceBase) {
    this.base = base;
  }

  /**
   * 테스트 전체 조회
   * @param {TestFindAllReq} params
   * @returns {Promise<CommonRes<TestFindAllRes>>}
   */
  getTest(params: TestFindAllReq): Promise<CommonRes<TestFindAllRes>> {
    return this.base.get<CommonRes<TestFindAllRes>, TestFindAllReq>(
      '/test',
      params
    );
  }

  /**
   * 테스트 등록
   * @param {TestSaveReq} data
   * @returns {Promise<CommonRes<TestSaveRes>>}
   */
  addTest(data: TestSaveReq): Promise<CommonRes<TestSaveRes>> {
    return this.base.post<CommonRes<TestSaveRes>, TestSaveReq>('/test', data);
  }
}

export default TestServiceImpl;

// const testService = new TestServiceImpl();
//
// export default testService;
