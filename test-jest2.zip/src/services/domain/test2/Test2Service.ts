export default interface Test2Service {
  getTest2<R, A>(params: A): Promise<R>;
  addTest2<R, A>(data: A): Promise<R>;
}
