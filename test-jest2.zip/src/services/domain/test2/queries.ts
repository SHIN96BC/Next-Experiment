import {
  Test2FindAllReq,
  Test2SaveReq,
} from '@Src/services/domain/test2/model';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findAll: readonly [string]}}
 */
const queryKeys = {
  findAll: ['test'] as const,
};

/**
 * React Query Options Object
 * @type {{save: () => {mutationFn: (data: TestSaveReq) => Promise<TestSaveRes>}, findAll: (params: TestFindAllReq) => {queryKey: readonly [string], queryFn: () => Promise<TestFindAllRes>}}}
 */
const queryOptions = {
  findAll: (params: Test2FindAllReq) => ({
    queryKey: queryKeys.findAll,
    queryFn: () =>
      serviceContainer.get<TestService>(SERVICE_NAME.TEST).getTest(params),
  }),
  save: () => ({
    mutationFn: (data: Test2SaveReq) =>
      serviceContainer.get<TestService>(SERVICE_NAME.TEST).addTest(data),
  }),
};

export default queryOptions;
