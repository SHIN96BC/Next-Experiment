import {
  Test2FindAllReq,
  Test2FindAllRes,
  Test2SaveReq,
  Test2SaveRes,
} from '@Src/services/domain/test2/model';
import { CommonRes } from '@Src/services/commonModel';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findAll: readonly [string]}}
 */
const queryKeys = {
  findAll: ['test'] as const,
};

/**
 * React Query Options Object
 * @type {{save: () => {mutationFn: (data: TestSaveReq) => Promise<TestSaveRes>}, findAll: (params: TestFindAllReq) => {queryKey: readonly [string], queryFn: () => Promise<TestFindAllRes>}}}
 */
const queryOptions = {
  findAll: (params: Test2FindAllReq) => ({
    queryKey: queryKeys.findAll,
    queryFn: () =>
      serviceContainer
        .get<TestService>(SERVICE_NAME.TEST)
        .getTest<CommonRes<Test2FindAllRes>, Test2FindAllReq>(params),
  }),
  save: () => ({
    mutationFn: (data: Test2SaveReq) =>
      serviceContainer
        .get<TestService>(SERVICE_NAME.TEST)
        .addTest<CommonRes<Test2SaveRes>, Test2SaveReq>(data),
  }),
};

export default queryOptions;
