import { useMutation, useQuery } from '@tanstack/react-query';
import queryOptions from '@Src/services/domain/test2/queries';
import { Test2FindAllReq } from '@Src/services/domain/test2/model';
import { useSession } from 'next-auth/react';

/**
 * Find All Test
 * @param {Test2FindAllReq} params
 * @returns {UseQueryResult<Test2FindAllRes, DefaultError>}
 */
export const useQueryFindAllTest2 = (params: Test2FindAllReq) => {
  const session = useSession();

  return useQuery({
    ...queryOptions.findAll(params),
    enabled: !!session?.data?.accessToken,
  });
};

/**
 * Save Test
 * @returns {UseMutationResult<CommonRes<Test2SaveRes>, DefaultError, Test2SaveReq, unknown>}
 */
export const useMutationSaveTest2 = () => useMutation(queryOptions.save());
