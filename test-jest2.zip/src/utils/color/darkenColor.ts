export default function darkenColor(hex: string, amount: number): string {
  // hex 값이 유효한지 검사 (정규식 사용)
  const isValidHex = /^#([0-9A-Fa-f]{3}){1,2}$/.test(hex);

  if (!isValidHex) {
    console.error(`Invalid hex color: ${hex}`);
    return hex; // 올바르지 않은 hex는 그대로 반환
  }

  // 3자리 hex를 6자리로 변환
  let newHex = hex;

  if (newHex.length === 4) {
    // newHex = `#${[...newHex.slice(1)].map((ch) => ch + ch).join('')}`;
    newHex = `#${newHex[1]}${newHex[1]}${newHex[2]}${newHex[2]}${newHex[3]}${newHex[3]}`;
  }

  const color = parseInt(newHex.slice(1), 16);
  let r = (color >> 16) - amount;
  let g = ((color >> 8) & 0x00ff) - amount;
  let b = (color & 0x0000ff) - amount;

  r = r < 0 ? 0 : r;
  g = g < 0 ? 0 : g;
  b = b < 0 ? 0 : b;

  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}
