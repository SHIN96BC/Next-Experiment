import CustomLocalStorage from '@Src/utils/storages/CustomLocalStorage';

describe('CustomLocalStorage', () => {
  beforeEach(() => {
    localStorage.clear();
    jest.clearAllMocks();
  });

  test('Empty value test set method', () => {
    const key = 'key';
    CustomLocalStorage.set(key, undefined);
    expect(CustomLocalStorage.get(key)).not.toBeDefined();
  });

  test('test set method', () => {
    const key = 'key';
    CustomLocalStorage.set(key, { name: 'name', value: 'value' });
    expect(CustomLocalStorage.get(key)).toEqual({
      name: 'name',
      value: 'value',
    });
  });

  test('test get method', () => {
    const key = 'key';

    CustomLocalStorage.set(key, { name: 'name', value: 'value' });
    expect(CustomLocalStorage.get(key)).toEqual({
      name: 'name',
      value: 'value',
    });
  });

  test('exception test get method', () => {
    const key = 'key';

    CustomLocalStorage.set(key, { name: 'name', value: 'value' });

    // CustomLocalStorage.get에서 예외를 발생시키도록 mock
    jest.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
      throw new Error('CustomLocalStorage.get');
    });

    expect(CustomLocalStorage.get(key)).not.toBeDefined();
  });

  test('test remove method', () => {
    const key = 'key';

    CustomLocalStorage.set(key, { name: 'name', value: 'value' });
    CustomLocalStorage.remove(key);

    expect(CustomLocalStorage.get(key)).not.toBeDefined();
  });

  test('test clear method', () => {
    const key1 = 'key1';
    const key2 = 'key2';

    CustomLocalStorage.set(key1, { name: 'name1', value: 'value1' });
    CustomLocalStorage.set(key2, { name: 'name2', value: 'value2' });
    CustomLocalStorage.clear();

    expect(CustomLocalStorage.get(key1)).not.toBeDefined();
    expect(CustomLocalStorage.get(key2)).not.toBeDefined();
  });
});
