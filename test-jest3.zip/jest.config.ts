import nextJest from 'next/jest';
import type { Config } from 'jest';

const createJestConfig = nextJest({ dir: './' });

const jestConfig: Config = {
  rootDir: './',
  coverageProvider: 'v8',
  setupFilesAfterEnv: [
    `<rootDir>/jest.polyfills.js`,
    '<rootDir>/jest.setup.ts',
  ],
  // testEnvironment: 'jest-environment-jsdom',
  testEnvironment: 'jsdom',
  moduleNameMapper: {
    '@Src/(.*)$': '<rootDir>/src/$1',
    '@App/(.*)$': '<rootDir>/src/app/$1',
    // '^@Pages(.*)$': '<rootDir>/src/pages/$1',
    '@Components/(.*)$': '<rootDir>/src/components/$1',
    'next-auth/(.*)': '<rootDir>/node_modules/next-auth/$1',
  },
  moduleDirectories: ['node_modules', '<rootDir>/src'],
  // cannot find module msw 를 해결하기 위한 설정
  testEnvironmentOptions: {
    customExportConditions: [''],
  },
  // 특정 파일 테스트 커버리지 항목에서 제외
  coveragePathIgnorePatterns: [
    `<rootDir>/node_modules/`,
    `<rootDir>/src/mocks/`,
  ],
};

export default createJestConfig(jestConfig);
