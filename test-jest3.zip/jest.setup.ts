import '@testing-library/jest-dom';
import { mockServer } from '@Src/mocks/server';

// react-dom mock 처리
jest.mock('react-dom', () => ({
  ...jest.requireActual('react-dom'),
  createPortal: jest.fn(),
}));

// next/navigation mock 처리
jest.mock('next/navigation', () => ({
  useRouter: jest.fn(),
}));

beforeAll(() => mockServer.listen());
// setupServer 호출 이후에 특정한 테스트를 위해 handler를 추가하면
// 이게 그걸 제거해줄겁니다
// ('테스트간 격리'를 위해 중요한 처리입니다)
afterEach(() => mockServer.resetHandlers());
afterAll(() => mockServer.close());

// global.fetch = jest.fn().mockResolvedValueOnce({
//   ok: true,
//   json: jest.fn(),
// });
