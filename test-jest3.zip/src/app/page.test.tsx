import { render, screen } from '@Src/jestUtils.test';
import Home from '@App/page';

describe('Test Page Home', () => {
  it('renders a heading', () => {
    // render(<Home />);
    //
    // const heading = screen.getByRole('heading', { level: 1, name: 'Home' });
    //
    // expect(heading).toBeInTheDocument();
  });
});
