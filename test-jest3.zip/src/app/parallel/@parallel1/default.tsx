export default function Parallel1Default() {
  return null;
}
