async function getData() {
  await new Promise((resolve) => {
    setTimeout(resolve, 3000);
  });

  return { result: 'result3', status: 200, isOk: true };
}

export default async function Parallel2Page() {
  const data = await getData();

  return (
    <div className="h-full bg-amber-500">
      <div>Parallel 2</div>
      <div>{data.result}</div>
    </div>
  );
}
