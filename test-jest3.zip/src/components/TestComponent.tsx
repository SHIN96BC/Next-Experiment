'use client';

import { useCallback, useEffect } from 'react';
import {
  useMutationSaveTest,
  useQueryFindAllTest,
} from '@Src/services/domain/test/useTestService';
import { useDispatch } from 'react-redux';
import { showCommonAlert } from '@Src/lib/common/alert/commonAlertSlice';
import { changeOpenMenusState } from '@Src/lib/common/menus/menusSlice';
import CustomBtn from '@Components/button/CommonBtn';

export default function TestComponent() {
  const dispatch = useDispatch();
  const { data, refetch } = useQueryFindAllTest({ key: 'test' });
  const { mutate, data: saveResultData } = useMutationSaveTest();

  const handleShowCommonAlert = useCallback(() => {
    dispatch(
      showCommonAlert({
        messageHTML: 'Test Alert',
        okBtnColor: 'primary',
      })
    );
  }, [dispatch]);

  const handleSaveTest = () => {
    mutate({
      key: '1234124123',
      name: '홍길동',
      email: 'test@test.com',
      phone: '000-0000-0000',
    });
  };

  const handleOpenMenu = useCallback(
    (menu: string) => {
      dispatch(changeOpenMenusState(menu));
    },
    [dispatch]
  );

  return (
    <div>
      <div>
        <div className="p-2">
          <CustomBtn onClick={() => refetch()}>Test Api Get</CustomBtn>
        </div>
        <div className="p-2">
          <CustomBtn onClick={handleSaveTest}>Test Api Post</CustomBtn>
        </div>
      </div>
      <div className="pt-3">
        <button
          className="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
          type="button"
          onClick={handleShowCommonAlert}
        >
          Common Alert
        </button>
      </div>
      <div className="pt-3">
        <p>persist test</p>
        <div className="p-2">
          <CustomBtn onClick={() => handleOpenMenu('menu1')}>menu1</CustomBtn>
        </div>
        <div className="p-2">
          <CustomBtn onClick={() => handleOpenMenu('menu2')}>menu2</CustomBtn>
        </div>
        <div className="p-2">
          <CustomBtn onClick={() => handleOpenMenu('menu3')}>menu3</CustomBtn>
        </div>
      </div>
    </div>
  );
}
