import Link from 'next/link';
import { ReactNode } from 'react';
import { ThemeColorsType } from '@Src/utils/theme/colors';

type Props = {
  children?: ReactNode;
  url: string;
  color?: ThemeColorsType;
};

export default function CommonLinkBtn({ children, url, color }: Props) {
  return (
    <Link
      className={`${color ? `hover:text-${color}` : 'hover:text-primary'}`}
      href={url}
    >
      {children}
    </Link>
  );
}
