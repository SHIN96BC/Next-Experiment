import Link from 'next/link';

export default function LoginBtn() {
  return (
    <Link href="/login" passHref>
      Login
    </Link>
  );
}
