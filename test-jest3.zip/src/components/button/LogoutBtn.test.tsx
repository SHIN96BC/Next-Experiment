import { render, screen, fireEvent } from '@Src/jestUtils.test';
import { signOut } from 'next-auth/react';
import LogoutBtn from '@Src/components/button/LogoutBtn';

describe('LogoutBtn', () => {
  it('calls signOut and redirects when clicked', async () => {
    const signOutMock = jest.fn(); // signOut mock
    // signOut이 mock 함수로 설정
    (signOut as jest.Mock).mockImplementation(signOutMock);

    await render(<LogoutBtn />, {
      session: {
        accessToken: 'testToken',
        refreshToken: '',
        expires: new Date(Date.now() + 2 * 86400).toISOString(),
        user: {
          id: '123432343',
          name: '홍길동',
          email: 'test@test.com',
          image: '',
        },
      },
    });

    // 버튼이 렌더링되었는지 확인
    const button = screen.getByRole('button', { name: /Logout/i });
    expect(button).toBeInTheDocument();

    // 버튼 클릭 이벤트 발생
    fireEvent.click(button);

    // signOut이 호출되었는지 확인
    expect(signOutMock).toHaveBeenCalledWith({
      redirect: true,
      callbackUrl: '/',
    });
  });
});
