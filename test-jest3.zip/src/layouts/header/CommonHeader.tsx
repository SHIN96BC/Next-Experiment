'use client';

import { useSession } from 'next-auth/react';
import LogoutBtn from '@Components/button/LogoutBtn';
import LoginBtn from '@Components/button/LoginBtn';
import HomeBtn from '@Components/button/HomeBtn';

export default function CommonHeader() {
  const session = useSession();

  return (
    <div className="sticky top-0 p-4 bg-primary text-white">
      <div className="w-full flex items-center justify-between">
        <div>
          <HomeBtn />
        </div>
        <div>{session && session.data ? <LogoutBtn /> : <LoginBtn />}</div>
      </div>
    </div>
  );
}
