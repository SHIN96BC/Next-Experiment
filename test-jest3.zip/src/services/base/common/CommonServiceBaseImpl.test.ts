import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import CommonServiceBaseImpl from '@Src/services/base/common/CommonServiceBaseImpl';

describe('ServiceBaseImpl', () => {
  let serviceBase: CommonServiceBase;

  beforeAll(() => {
    jest.clearAllMocks();
    serviceBase = new CommonServiceBaseImpl();
  });

  test('setToken test ', () => {
    if (serviceBase.setToken && serviceBase.getToken) {
      serviceBase.setToken('test1');
      expect(serviceBase.getToken()).toEqual('test1');
    }
  });

  test('get error test', async () => {
    // throw 테스트의 경우 expect 자체에 await를 걸어줘야함
    await expect(serviceBase.get('/test/error')).rejects.toThrow(
      'Network response was not ok'
    );
  });

  test('get server error test', async () => {
    await expect(serviceBase.get('/test/network_error')).rejects.toThrow(
      'Failed to fetch'
    );
  });

  test('post error test', async () => {
    await expect(serviceBase.post('/test/error')).rejects.toThrow(
      'Network response was not ok'
    );
  });

  test('post server error test', async () => {
    await expect(serviceBase.post('/test/network_error')).rejects.toThrow(
      'Failed to fetch'
    );
  });

  test('get test', async () => {
    expect(
      await serviceBase.get('/test', {
        key: '@test1',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { name: 'test', email: 'test@test.com', phone: '000-0000-0000' },
    });
  });

  test('delete test', async () => {
    expect(
      await serviceBase.delete('/test', {
        key: '@test1',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });

  test('head test', async () => {
    expect(await serviceBase.head('/test')).toEqual({
      status: 200,
      ok: true,
    });
  });

  test('options test', async () => {
    expect(await serviceBase.options('/test')).toEqual({
      status: 200,
      ok: true,
    });
  });

  test('post test', async () => {
    expect(
      await serviceBase.post('/test', {
        name: 'test',
        email: 'test@test.com',
        phone: '000-0000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });

  test('post and header test', async () => {
    expect(
      await serviceBase.post(
        '/test',
        {
          name: 'test',
          email: 'test@test.com',
          phone: '000-0000-0000',
        },
        {
          headers: {
            'Content-Type': 'application/json; charset=utf-8',
          },
        }
      )
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });

  test('put test', async () => {
    expect(
      await serviceBase.put('/test', {
        key: '@test1',
        name: 'test2',
        email: 'test2@test.com',
        phone: '000-2000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });

  test('patch test', async () => {
    expect(
      await serviceBase.patch('/test', {
        key: '@test1',
        name: 'test3',
        email: 'test3@test.com',
        phone: '000-3000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });
});
