let idCounter = 0;

export default function getBindingId(): number {
  // eslint-disable-next-line no-plusplus
  return idCounter++;
}
