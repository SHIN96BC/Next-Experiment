import { BINDING_SCOPE, SERVICE_NAME } from '@Src/services/constants';
import TestServiceImpl from '@Src/services/domain/test/TestServiceImpl';
import CommonServiceBaseImpl from '@Src/services/base/common/CommonServiceBaseImpl';
import { BatchBinding } from '@Src/services/type';
import AuthServiceImpl from '@Src/services/domain/auth/AuthServiceImpl';
import ServiceContainer from '@Src/services/container/ServiceContainer';
import ServiceContainerImpl from '@Src/services/container/ServiceContainerImpl';
import FileServiceBaseImpl from '@Src/services/base/file/FileServiceBaseImpl';
import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import { FileServiceBase } from '@Src/services/base/file/FileServiceBase';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import Test2ServiceImpl from '@Src/services/domain/test2/Test2ServiceImpl';

const serviceBatchList: BatchBinding[] = [
  {
    name: SERVICE_NAME.TEST,
    target: TestServiceImpl,
    baseName: SERVICE_NAME.COMMON_BASE,
    scope: BINDING_SCOPE.SINGLETON,
  },
  {
    name: SERVICE_NAME.AUTH,
    target: AuthServiceImpl,
    baseName: SERVICE_NAME.COMMON_BASE,
    scope: BINDING_SCOPE.REQUEST,
  },
];

/**
 * Service Container Instance
 * @type {ServiceContainer}
 */
const serviceContainer: ServiceContainer = new ServiceContainerImpl();

/// ///////////////////////////////////////////////////////////////////////////////////////////////
// region - Dependency Injection
/// ///////////////////////////////////////////////////////////////////////////////////////////////

// * Bind Service Base
serviceContainer
  .baseBind<CommonServiceBase>(SERVICE_NAME.COMMON_BASE)
  .to(CommonServiceBaseImpl)
  .inSingletonScope()
  .build();

serviceContainer
  .baseBind<FileServiceBase>(SERVICE_NAME.FILE_BASE)
  .to(FileServiceBaseImpl)
  .inSingletonScope()
  .build();

// * Bind Service
// service 하나씩 수동 등록
serviceContainer
  .bind<Test2Service>(SERVICE_NAME.TEST2)
  .to(Test2ServiceImpl)
  .base(SERVICE_NAME.COMMON_BASE)
  .inSingletonScope()
  .build();

// service 한번에 batch 등록
serviceContainer.batchBind(serviceBatchList);

/// ///////////////////////////////////////////////////////////////////////////////////////////////
// endregion - Dependency Injection
/// ///////////////////////////////////////////////////////////////////////////////////////////////

export { serviceContainer };

export default undefined;
