import { BatchBinding } from '@Src/services/type';
import Binding from '@Src/services/binding/Binding';

export default interface ServiceContainer {
  bind<T>(name: symbol): Binding<T>;
  baseBind<T>(name: symbol): Binding<T>;
  batchBind(list: BatchBinding[]): void;
  unbind(name: symbol): void;
  baseUnbind(name: symbol): void;
  get<T>(name: symbol): T;
  isBound(name: symbol): boolean;
  setToken(token: string): Promise<void>;
  clearToken(): Promise<void>;
}
