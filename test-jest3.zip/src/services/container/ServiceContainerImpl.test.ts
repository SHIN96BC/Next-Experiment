import TestServiceImpl from '@Src/services/domain/test/TestServiceImpl';
import AuthServiceImpl from '@Src/services/domain/auth/AuthServiceImpl';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';
import TestService from '@Src/services/domain/test/TestService';
import AuthService from '@Src/services/domain/auth/AuthService';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import Test2ServiceImpl from '@Src/services/domain/test2/Test2ServiceImpl';
import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';

describe('ServiceContainer', () => {
  test('should register and get service correctly', () => {
    const testService = serviceContainer.get<TestService>(SERVICE_NAME.TEST);
    const authService = serviceContainer.get<AuthService>(SERVICE_NAME.AUTH);

    expect(testService).toBeInstanceOf(TestServiceImpl);
    expect(authService).toBeInstanceOf(AuthServiceImpl);
  });

  // test('should register and resolve service correctly', () => {
  //   const testService = serviceContainer.resolveService<TestServiceImpl>(
  //     SERVICE_NAME.TEST
  //   );
  //   const authService = serviceContainer.resolveService<AuthServiceImpl>(
  //     SERVICE_NAME.AUTH
  //   );
  //
  //   expect(testService).toBeInstanceOf(TestServiceImpl);
  //   expect(authService).toBeInstanceOf(AuthServiceImpl);
  // });

  test('should resolve service is not found', () => {
    const serviceName = Symbol.for('testService2');
    // toThrow 를 테스트는 expect 첫번째 인자를 함수로 줘야함
    expect(() => {
      serviceContainer.get(serviceName);
    }).toThrow(`Service ${serviceName.toString()} not found`);
  });

  test('should service and base is already bound', () => {
    // toThrow 를 테스트는 expect 첫번째 인자를 함수로 줘야함
    expect(() => {
      serviceContainer.baseBind<CommonServiceBase>(SERVICE_NAME.COMMON_BASE);
    }).toThrow(
      `Service Base ${SERVICE_NAME.COMMON_BASE.toString()} already bound`
    );

    expect(() => {
      serviceContainer.bind<Test2Service>(SERVICE_NAME.TEST2);
    }).toThrow(`Service ${SERVICE_NAME.TEST2.toString()} already bound`);
  });

  test('should service and base not exists', () => {
    const name = Symbol.for('NAME');

    // toThrow 를 테스트는 expect 첫번째 인자를 함수로 줘야함
    expect(() => {
      serviceContainer.baseUnbind(name);
    }).toThrow(`Service Base ${name.toString()} not exists`);

    expect(() => {
      serviceContainer.unbind(name);
    }).toThrow(`Service ${name.toString()} not exists`);
  });

  // test('should set and clear token correctly', async () => {
  //   // const mockService = {
  //   //   setToken: jest.fn(),
  //   // };
  //
  //   class MockService {
  //     public token: string | undefined;
  //
  //     setToken(token: string) {
  //       this.token = token;
  //     }
  //
  //     getToken(): string | undefined {
  //       return this.token;
  //     }
  //   }
  //
  //   const name = Symbol.for('mockService');
  //
  //   serviceContainer
  //     .baseBind<MockService>(name)
  //     .to(MockService)
  //     .inSingletonScope()
  //     .build();
  //
  //   await serviceContainer.setToken('test-token');
  //
  //   const mockService = serviceContainer.get<MockService>(name);
  //
  //   expect(mockService.getToken()).toHaveBeenCalledWith('test-token');
  //
  //   await serviceContainer.clearToken();
  //   expect(mockService.getToken()).toHaveBeenCalledWith(null);
  // });
});
