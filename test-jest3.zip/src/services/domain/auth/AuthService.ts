import { LoginPostReq, LoginPostRes } from '@Src/services/domain/auth/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface AuthService {
  postLogin(data: LoginPostReq): Promise<CommonRes<LoginPostRes>>;
  postLogout(): Promise<CommonRes>;
}
