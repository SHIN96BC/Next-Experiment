import AuthServiceImpl from '@Src/services/domain/auth/AuthServiceImpl';
import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import CommonServiceBaseImpl from '@Src/services/base/common/CommonServiceBaseImpl';

describe('AuthService', () => {
  let serviceBase: CommonServiceBase;

  beforeEach(() => {
    jest.clearAllMocks();
    serviceBase = new CommonServiceBaseImpl();
  });

  test('login test', async () => {
    const service = new AuthServiceImpl(serviceBase);
    expect(
      await service.postLogin({
        email: 'test@test.com',
        password: 'qwer1234!@',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: {
        user: {
          id: '123432343',
          name: '홍길동',
          email: 'test@test.com',
        },
        access_token: 'testToken@@@!@#!@#!@#!@#$%',
        refresh_token: 'refreshToken!@#!@$@%@#$!@',
      },
    });
  });

  test('logout 테스트', async () => {
    const service = new AuthServiceImpl(serviceBase);
    expect(await service.postLogout()).toEqual({
      status: 200,
      ok: true,
    });
  });
});
