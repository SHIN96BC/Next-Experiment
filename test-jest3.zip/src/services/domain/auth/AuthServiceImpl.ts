import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import AuthService from '@Src/services/domain/auth/AuthService';
import { LoginPostReq, LoginPostRes } from '@Src/services/domain/auth/model';
import { CommonRes } from '@Src/services/commonModel';

class AuthServiceImpl implements AuthService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly base: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} base
   */
  constructor(base: CommonServiceBase) {
    this.base = base;
  }

  /**
   * 로그인
   * @param {LoginPostReq} data
   * @returns {Promise<CommonRes<LoginPostRes>>}
   */
  postLogin(data: LoginPostReq): Promise<CommonRes<LoginPostRes>> {
    return this.base.post<CommonRes<LoginPostRes>, LoginPostReq>(
      '/login',
      data
    );
  }

  /**
   * 로그아웃
   * @returns {Promise<CommonRes>}
   */
  postLogout(): Promise<CommonRes> {
    return this.base.post<CommonRes>('/logout');
  }
}

export default AuthServiceImpl;
