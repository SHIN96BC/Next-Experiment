export interface AuthLoginReq {
  email: string;
  password: string;
}

export interface AuthLoginRes {
  name: string;
  accessToken: string;
}

export interface AuthLogoutRes {}
