export interface LoginPostReq {
  email: string;
  password: string;
}

export interface LoginPostRes {
  name: string;
  accessToken: string;
}

export interface LogoutPostRes {}
