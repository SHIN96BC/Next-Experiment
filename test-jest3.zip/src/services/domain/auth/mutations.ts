import { AuthLoginReq } from '@Src/services/domain/auth/model';
import AuthService from '@Src/services/domain/auth/AuthService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

const mutationKeys = {
  login: ['login'] as const,
  logout: ['logout'] as const,
};

const mutationOptions = {
  login: () => ({
    mutationKey: mutationKeys.login,
    mutationFn: (data: AuthLoginReq) =>
      serviceContainer.get<AuthService>(SERVICE_NAME.AUTH).login(data),
  }),
  logout: () => ({
    mutationKey: mutationKeys.logout,
    mutationFn: () =>
      serviceContainer.get<AuthService>(SERVICE_NAME.AUTH).logout(),
  }),
};

export default mutationOptions;
