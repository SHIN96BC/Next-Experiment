import { useMutation } from '@tanstack/react-query';
import mutationOptions from '@Src/services/domain/auth/mutations';

export const useMutationLogin = () => useMutation(mutationOptions.login());

export const useMutationLogout = () => useMutation(mutationOptions.logout());
