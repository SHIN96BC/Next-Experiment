import {
  TestGetReq,
  TestGetRes,
  TestPostReq,
  TestPostRes,
} from '@Src/services/domain/test/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface TestService {
  getTest(params: TestGetReq): Promise<CommonRes<TestGetRes>>;
  postTest(data: TestPostReq): Promise<CommonRes<TestPostRes>>;
}
