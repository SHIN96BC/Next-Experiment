import {
  TestFindAllReq,
  TestFindAllRes,
  TestSaveReq,
  TestSaveRes,
} from '@Src/services/domain/test/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface TestService {
  getTest(params: TestFindAllReq): Promise<CommonRes<TestFindAllRes>>;
  addTest(data: TestSaveReq): Promise<CommonRes<TestSaveRes>>;
}
