import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import CommonServiceBaseImpl from '@Src/services/base/common/CommonServiceBaseImpl';
import TestServiceImpl from '@Src/services/domain/test/TestServiceImpl';

describe('Test Service', () => {
  let serviceBase: CommonServiceBase;

  beforeEach(() => {
    jest.clearAllMocks();
    serviceBase = new CommonServiceBaseImpl();
  });

  test('getTest test', async () => {
    const service = new TestServiceImpl(serviceBase);
    expect(await service.getTest({ key: 'test1' })).toEqual({
      status: 200,
      ok: true,
      result: { name: 'test', email: 'test@test.com', phone: '000-0000-0000' },
    });
  });

  test('postTest test', async () => {
    const service = new TestServiceImpl(serviceBase);
    expect(
      await service.postTest({
        key: '1234434',
        name: 'test',
        email: 'test@test.com',
        phone: '000-0000-0000',
      })
    ).toEqual({
      status: 200,
      ok: true,
      result: { isOk: true },
    });
  });
});
