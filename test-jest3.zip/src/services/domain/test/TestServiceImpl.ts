import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import TestService from '@Src/services/domain/test/TestService';
import {
  TestGetReq,
  TestGetRes,
  TestPostReq,
  TestPostRes,
} from '@Src/services/domain/test/model';
import { CommonRes } from '@Src/services/commonModel';

class TestServiceImpl implements TestService {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly base: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} base
   */
  constructor(base: CommonServiceBase) {
    this.base = base;
  }

  /**
   * 테스트 전체 조회
   * @param {TestGetReq} params
   * @returns {Promise<CommonRes<TestGetRes>>}
   */
  getTest(params: TestGetReq): Promise<CommonRes<TestGetRes>> {
    return this.base.get<CommonRes<TestGetRes>, TestGetReq>('/test', params);
  }

  /**
   * 테스트 등록
   * @param {TestPostReq} data
   * @returns {Promise<CommonRes<TestPostRes>>}
   */
  postTest(data: TestPostReq): Promise<CommonRes<TestPostRes>> {
    return this.base.post<CommonRes<TestPostRes>, TestPostReq>('/test', data);
  }
}

export default TestServiceImpl;

// const testService = new TestServiceImpl();
//
// export default testService;
