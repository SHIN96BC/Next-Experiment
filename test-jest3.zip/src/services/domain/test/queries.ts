import { TestGetReq } from '@Src/services/domain/test/model';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findAll: readonly [string]}}
 */
const queryKeys = {
  findTest: ['findTest'] as const,
};

/**
 * React Query Options Object
 * @type {{save: () => {mutationFn: (data: TestPostReq) => Promise<TestPostRes>}, findAll: (params: TestGetReq) => {queryKey: readonly [string], queryFn: () => Promise<TestGetRes>}}}
 */
const queryOptions = {
  findTest: (params: TestGetReq) => ({
    queryKey: queryKeys.findTest,
    queryFn: () =>
      serviceContainer.get<TestService>(SERVICE_NAME.TEST).getTest(params),
  }),
};

export default queryOptions;
