import { useMutation, useQuery } from '@tanstack/react-query';
import queryOptions from '@Src/services/domain/test/queries';
import { TestGetReq } from '@Src/services/domain/test/model';
import { useSession } from 'next-auth/react';
import mutationOptions from '@Src/services/domain/test/mutations';

/**
 * Find All Test
 * @param {TestGetReq} params
 * @returns {UseQueryResult<TestGetRes, DefaultError>}
 */
export const useQueryFindAllTest = (params: TestGetReq) => {
  const session = useSession();

  return useQuery({
    ...queryOptions.findTest(params),
    enabled: !!session?.data?.accessToken,
  });
};

/**
 * Save Test
 * @returns {UseMutationResult<CommonRes<TestPostRes>, DefaultError, TestPostReq, unknown>}
 */
export const useMutationSaveTest = () =>
  useMutation(mutationOptions.registerTest());
