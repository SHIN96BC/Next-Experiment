import {
  Test2GetReq,
  Test2GetRes,
  Test2PostReq,
  Test2PostRes,
} from '@Src/services/domain/test2/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface Test2Service {
  getTest2(params: Test2GetReq): Promise<CommonRes<Test2GetRes>>;
  postTest2(data: Test2PostReq): Promise<CommonRes<Test2PostRes>>;
}
