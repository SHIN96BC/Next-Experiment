import {
  Test2FindAllReq,
  Test2FindAllRes,
  Test2SaveReq,
  Test2SaveRes,
} from '@Src/services/domain/test2/model';
import { CommonRes } from '@Src/services/commonModel';

export default interface Test2Service {
  getTest2(params: Test2FindAllReq): Promise<CommonRes<Test2FindAllRes>>;
  addTest2(data: Test2SaveReq): Promise<CommonRes<Test2SaveRes>>;
}
