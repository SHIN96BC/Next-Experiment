import { CommonServiceBase } from '@Src/services/base/common/CommonServiceBase';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import {
  Test2GetReq,
  Test2GetRes,
  Test2PostReq,
  Test2PostRes,
} from '@Src/services/domain/test2/model';
import { CommonRes } from '@Src/services/commonModel';

class TestServiceImpl implements Test2Service {
  /**
   * API Service 객체(DIP 원칙에 따라 구현체가 아닌 Interface(CommonServiceBase)에만 의존
   * @type {CommonServiceBase}
   * @private
   */
  private readonly base: CommonServiceBase;

  /**
   * 생성자 주입 방식 사용
   * @param {CommonServiceBase} base
   */
  constructor(base: CommonServiceBase) {
    this.base = base;
  }

  /**
   * 테스트 전체 조회
   * @param {Test2GetReq} params
   * @returns {Promise<CommonRes<Test2GetRes>>}
   */
  getTest2(params: Test2GetReq): Promise<CommonRes<Test2GetRes>> {
    return this.base.get<CommonRes<Test2GetRes>, Test2GetReq>('/test2', params);
  }

  /**
   * 테스트 등록
   * @param {Test2PostReq} data
   * @returns {Promise<CommonRes<Test2PostRes>>}
   */
  postTest2(data: Test2PostReq): Promise<CommonRes<Test2PostRes>> {
    return this.base.post<CommonRes<Test2PostRes>, Test2PostReq>(
      '/test2',
      data
    );
  }
}

export default TestServiceImpl;

// const testService = new TestServiceImpl();
//
// export default testService;
