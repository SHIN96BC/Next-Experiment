export interface Test2GetReq {
  key: string;
}

export interface Test2GetRes {
  name: string;
  email: string;
  phone: string;
}

export interface Test2PostReq {
  key: string;
  name: string;
  email: string;
  phone: string;
}

export interface Test2PostRes {
  isOk: boolean;
}
