import { Test2PostReq } from '@Src/services/domain/test2/model';
import { serviceContainer } from '@Src/services/config';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import { SERVICE_NAME } from '@Src/services/constants';

const mutationKeys = {
  registerTest2: ['registerTest2'] as const,
};

const mutationOptions = {
  registerTest2: () => ({
    mutationKey: mutationKeys.registerTest2,
    mutationFn: (data: Test2PostReq) =>
      serviceContainer.get<Test2Service>(SERVICE_NAME.TEST2).postTest2(data),
  }),
};

export default mutationOptions;
