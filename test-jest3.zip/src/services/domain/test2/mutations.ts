import { TestSaveReq } from '@Src/services/domain/test/model';
import { serviceContainer } from '@Src/services/config';
import TestService from '@Src/services/domain/test/TestService';
import { SERVICE_NAME } from '@Src/services/constants';

const mutationKeys = {
  save2: ['save2'] as const,
};

const mutationOptions = {
  save2: () => ({
    mutationKey: mutationKeys.save2,
    mutationFn: (data: TestSaveReq) =>
      serviceContainer.get<TestService>(SERVICE_NAME.TEST).addTest(data),
  }),
};

export default mutationOptions;
