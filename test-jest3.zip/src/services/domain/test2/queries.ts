import {
  Test2FindAllReq,
  Test2SaveReq,
} from '@Src/services/domain/test2/model';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findAll: readonly [string]}}
 */
const queryKeys = {
  findAll2: ['findAll2'] as const,
};

/**
 * React Query Options Object
 * @type {{save: () => {mutationFn: (data: TestSaveReq) => Promise<TestSaveRes>}, findAll: (params: TestFindAllReq) => {queryKey: readonly [string], queryFn: () => Promise<TestFindAllRes>}}}
 */
const queryOptions = {
  findAll2: (params: Test2FindAllReq) => ({
    queryKey: queryKeys.findAll2,
    queryFn: () =>
      serviceContainer.get<Test2Service>(SERVICE_NAME.TEST2).getTest2(params),
  }),
};

export default queryOptions;
