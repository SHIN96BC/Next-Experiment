import { Test2GetReq } from '@Src/services/domain/test2/model';
import Test2Service from '@Src/services/domain/test2/Test2Service';
import { SERVICE_NAME } from '@Src/services/constants';
import { serviceContainer } from '@Src/services/config';

/**
 * React Query Keys Object
 * @type {{findTest2: readonly [string]}}
 */
const queryKeys = {
  findTest2: ['findTest2'] as const,
};

/**
 * React Query Options Object
 * @type {{findTest2: (params: Test2GetReq) => {queryKey: readonly [string], queryFn: () => Promise<Test2GetRes>}}}
 */
const queryOptions = {
  findTest2: (params: Test2GetReq) => ({
    queryKey: queryKeys.findTest2,
    queryFn: () =>
      serviceContainer.get<Test2Service>(SERVICE_NAME.TEST2).getTest2(params),
  }),
};

export default queryOptions;
