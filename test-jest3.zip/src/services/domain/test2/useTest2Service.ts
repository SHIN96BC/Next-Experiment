import { useMutation, useQuery } from '@tanstack/react-query';
import queryOptions from '@Src/services/domain/test2/queries';
import { Test2GetReq } from '@Src/services/domain/test2/model';
import { useSession } from 'next-auth/react';
import mutationOptions from '@Src/services/domain/test2/mutations';

/**
 * Find All Test
 * @param {Test2GetReq} params
 * @returns {UseQueryResult<Test2GetRes, DefaultError>}
 */
export const useQueryFindAllTest2 = (params: Test2GetReq) => {
  const session = useSession();

  return useQuery({
    ...queryOptions.findTest2(params),
    enabled: !!session?.data?.accessToken,
  });
};

/**
 * Save Test
 * @returns {UseMutationResult<CommonRes<Test2PostRes>, DefaultError, Test2PostReq, unknown>}
 */
export const useMutationSaveTest2 = () =>
  useMutation(mutationOptions.registerTest2());
