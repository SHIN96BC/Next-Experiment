import { BindingScopeType } from '@Src/services/constants';

export type Constructor<T = any> = new (...args: any[]) => T;

export type BatchBinding = {
  name: symbol;
  target: Constructor;
  baseName: symbol;
  scope: BindingScopeType;
};
