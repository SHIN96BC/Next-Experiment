import convertToQueryString, {
  QueryParamObject,
} from '@Src/utils/services/convertToQueryString';

test('should test convertToQueryString to an empty object', () => {
  const data: QueryParamObject = {};
  expect(convertToQueryString(data)).toEqual('');
});

test('should test convertToQueryString', () => {
  const data: QueryParamObject = {
    name: 'Alice',
    age: 30,
    isActive: true,
    tags: ['developer', 'typescript'],
    address: {
      city: 'San Francisco',
      zipCode: '94105',
    },
    projects: [
      { title: 'Project A', year: 2024 },
      { title: 'Project B', year: 2023 },
    ],
    history: [
      { year: 2021, events: ['event1', 'event2'] },
      { year: 2022, events: ['event3'] },
      {
        year: 2022,
        events: [
          ['event1', 'event2'],
          ['event1', 'event2'],
        ],
      },
    ],
    nestedArray: [
      [{ key1: 'value1' }, { key2: 'value2' }],
      [{ key3: 'value3' }],
    ],
  };
  expect(convertToQueryString(data)).toEqual(
    'name=Alice&age=30&isActive=true&tags%5B0%5D=developer&tags%5B1%5D=typescript&address%5Bcity%5D=San+Francisco&address%5BzipCode%5D=94105&projects%5B0%5D%5Btitle%5D=Project+A&projects%5B0%5D%5Byear%5D=2024&projects%5B1%5D%5Btitle%5D=Project+B&projects%5B1%5D%5Byear%5D=2023&history%5B0%5D%5Byear%5D=2021&history%5B0%5D%5Bevents%5D%5B0%5D=event1&history%5B0%5D%5Bevents%5D%5B1%5D=event2&history%5B1%5D%5Byear%5D=2022&history%5B1%5D%5Bevents%5D%5B0%5D=event3&history%5B2%5D%5Byear%5D=2022&history%5B2%5D%5Bevents%5D%5B0%5D%5B0%5D=event1&history%5B2%5D%5Bevents%5D%5B0%5D%5B1%5D=event2&history%5B2%5D%5Bevents%5D%5B1%5D%5B0%5D=event1&history%5B2%5D%5Bevents%5D%5B1%5D%5B1%5D=event2&nestedArray%5B0%5D%5B0%5D%5Bkey1%5D=value1&nestedArray%5B0%5D%5B1%5D%5Bkey2%5D=value2&nestedArray%5B1%5D%5B0%5D%5Bkey3%5D=value3'
  );
});
