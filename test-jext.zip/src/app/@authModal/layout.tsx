import GuestGuard from '@Src/utils/auth/GuestGuard';

export default function AuthModalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <GuestGuard>{children}</GuestGuard>;
}
