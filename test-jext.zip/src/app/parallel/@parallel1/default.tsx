export default function Parallel1DefaultPage() {
  return null;
}
