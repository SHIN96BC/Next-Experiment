import { render, RenderOptions } from '@testing-library/react';
import { ReactNode } from 'react';
import StoreProvider from '@Src/lib/StoreProvider';
import ReactQueryProvider from '@Src/services/ReactQueryProvider';
import AuthProvider from '@Src/utils/auth/AuthProvider';
import { Session } from 'next-auth';

// test 파일에 test가 없어서 발생하는 lint 에러를 위한 의미없는 코드
describe('Basic Jest Test Suite', () => {
  it('should run a simple test', () => {
    expect(true).toBe(true);
  });
});

// 필요한 provider들을 감싼 customRender 함수를 만들어 공통으로 사용할 수 있도록 함
const customRender = (
  ui: ReactNode,
  {
    options,
    session,
  }: {
    options?: RenderOptions;
    session?: Session;
  } = {}
) =>
  render(ui, {
    wrapper: ({ children }) => (
      <StoreProvider>
        <ReactQueryProvider>
          <AuthProvider session={session || null}>{children}</AuthProvider>
        </ReactQueryProvider>
      </StoreProvider>
    ),
    ...options,
  });

// redux 공식문서에 나온대로 dispatch 동작을 테스트하려면 미들웨어가 필요함
const storeThunkMiddleware =
  ({ dispatch, getState }: any) =>
  (next: any) =>
  (action: any) => {
    if (typeof action === 'function') {
      return action(dispatch, getState);
    }

    return next(action);
  };

// redux와 같은 방식으로 미들웨어를 실행하여 사용한 testStore를 만드는 함수
const testStoreCreate = () => {
  const store = {
    getState: jest.fn(() => ({})),
    dispatch: jest.fn(),
  };
  const next = jest.fn();

  const invoke = (action: any) => storeThunkMiddleware(store)(next)(action);

  return { store, next, invoke };
};

// testing에 필요한 모든것을 export
export * from '@testing-library/react';

// custom한 함수들 export
export { customRender as render, testStoreCreate };

export default undefined;
