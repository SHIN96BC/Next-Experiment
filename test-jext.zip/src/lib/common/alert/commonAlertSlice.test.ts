import reducer, {
  showCommonAlert,
  hideCommonAlert,
} from '@Src/lib/common/alert/commonAlertSlice';

test('should return the initial state', () => {
  expect(reducer(undefined, { type: 'unknown' })).toEqual({
    isShow: false,
    messageHTML: '',
  });
});

test('should test showCommonAlert is only message', () => {
  const result = reducer(
    undefined,
    showCommonAlert({
      messageHTML: 'test message',
    })
  );

  expect(result.isShow).toBe(true);
  expect(result.messageHTML).toBe('test message');
  expect(result.okBtnName).toBeUndefined();
  expect(result.okBtnColor).toBeUndefined();
  expect(result.cancelBtnName).toBeUndefined();
  expect(result.cancelBtnColor).toBeUndefined();

  // 콜백 함수는 정의된 상태인지 여부만 확인
  expect(result.okBtnCallback).toBeUndefined();
  expect(result.cancelBtnCallback).toBeUndefined();
});

test('should test showCommonAlert', () => {
  const result = reducer(
    undefined,
    showCommonAlert({
      messageHTML: 'test message',
      okBtnName: 'OK',
      okBtnColor: 'primary',
      okBtnCallback: () => {},
      cancelBtnName: 'Cancel',
      cancelBtnColor: 'secondary',
      cancelBtnCallback: () => {},
    })
  );

  expect(result.isShow).toBe(true);
  expect(result.messageHTML).toBe('test message');
  expect(result.okBtnName).toBe('OK');
  expect(result.okBtnColor).toBe('primary');
  expect(result.cancelBtnName).toBe('Cancel');
  expect(result.cancelBtnColor).toBe('secondary');

  // 콜백 함수는 정의된 상태인지 여부만 확인
  expect(typeof result.okBtnCallback).toBe('function');
  expect(typeof result.cancelBtnCallback).toBe('function');
});

test('should test hideCommonAlert', () => {
  expect(reducer(undefined, hideCommonAlert())).toEqual({
    isShow: false,
    messageHTML: '',
  });
});
