import reducer, { setTestName } from '@Src/lib/features/test/testSlice';

test('should return the initial state', () => {
  expect(reducer(undefined, { type: 'unknown' })).toEqual({ testName: '' });
});

test('should test setTestName', () => {
  expect(reducer(undefined, setTestName('testName1'))).toEqual({
    testName: 'testName1',
  });
});
