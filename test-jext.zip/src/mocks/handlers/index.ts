import authMockHandler from '@Src/mocks/handlers/auth/authMockHandler';
import testMockHandler from '@Src/mocks/handlers/test/testMockHandler';
import fileMockHandler from '@Src/mocks/handlers/file/fileMockHandler';

export default [...authMockHandler, ...testMockHandler, ...fileMockHandler];
