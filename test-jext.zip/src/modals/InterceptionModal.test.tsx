import { render, screen, fireEvent } from '@Src/jestUtils.test';
import { createPortal } from 'react-dom';
import InterceptionModal from '@Src/modals/InterceptionModal';
import { useRouter } from 'next/navigation';

describe('InterceptionModal', () => {
  let mockRouterBack: jest.Mock;

  beforeEach(() => {
    // 모달 포탈이 생성되는 root element 추가
    const portalRoot = document.getElementById('modal-root');
    if (!portalRoot) {
      const modalRoot = document.createElement('div');
      modalRoot.setAttribute('id', 'modal-root');
      document.body.appendChild(modalRoot);
    }

    // dialog 기능 세팅
    HTMLDialogElement.prototype.showModal = jest.fn(function mock(
      this: HTMLDialogElement
    ) {
      this.open = true;
    });

    // useRouter의 back 함수를 mock으로 만듦
    mockRouterBack = jest.fn();
    (useRouter as jest.Mock).mockReturnValue({ back: mockRouterBack });
  });

  afterEach(() => {
    // 포탈 루트 정리
    document.body.removeChild(document.getElementById('modal-root')!);
    jest.clearAllMocks();
  });

  it('renders modal in #modal-root using createPortal', () => {
    // 실제 createPortal을 mock하여 모달이 modal-root에 렌더링되었는지 확인
    const modalRoot = document.getElementById('modal-root')!;

    // createPortal이 실제로 호출되면 해당 요소를 modal-root에 넣도록 설정
    (createPortal as jest.Mock).mockImplementation((element, target) => {
      expect(target).toEqual(modalRoot); // target이 modal-root인지 확인
      return element;
    });

    render(<InterceptionModal>Test content</InterceptionModal>);

    // 모달이 렌더링되었는지 확인
    expect(screen.getByRole('dialog')).toBeInTheDocument();
    expect(screen.getByText('Test content')).toBeInTheDocument();
  });

  it('shows modal when mounted', () => {
    const dialogMock = { showModal: jest.fn(), open: false };
    jest
      .spyOn(HTMLDialogElement.prototype, 'showModal')
      .mockImplementation(dialogMock.showModal);

    render(<InterceptionModal>Test content</InterceptionModal>);

    // useEffect가 작동해서 showModal이 호출되었는지 확인
    expect(dialogMock.showModal).toHaveBeenCalled();
  });

  it('calls router.back when closed', () => {
    render(<InterceptionModal>Test content</InterceptionModal>);

    // 닫기 버튼 클릭
    fireEvent.click(screen.getByRole('button'));

    // router.back이 호출되었는지 확인
    expect(mockRouterBack).toHaveBeenCalled();
  });

  it('applies maxWidth and maxHeight correctly', () => {
    render(
      <InterceptionModal maxWidth={600} maxHeight={400}>
        Test content
      </InterceptionModal>
    );

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveClass('max-w-[600px]');
    expect(dialog).toHaveClass('max-h-[400px]');
  });

  it('applies string maxWidth and maxHeight correctly', () => {
    render(
      <InterceptionModal maxWidth="50%" maxHeight="75%">
        Test content
      </InterceptionModal>
    );

    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveClass('max-w-[50%]');
    expect(dialog).toHaveClass('max-h-[75%]');
  });
});
