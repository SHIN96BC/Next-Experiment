import serviceContainer from '@Src/services/ServiceContainer';
import TestService from '@Src/services/test/TestService';
import AuthService from '@Src/services/auth/AuthService';

describe('ServiceContainer', () => {
  test('should register and resolve service correctly', () => {
    const testService =
      serviceContainer.resolveService<TestService>('testService');
    const authService =
      serviceContainer.resolveService<AuthService>('authService');

    expect(testService).toBeInstanceOf(TestService);
    expect(authService).toBeInstanceOf(AuthService);
  });

  test('should register and resolve service correctly', () => {
    const testService =
      serviceContainer.resolveService<TestService>('testService');
    const authService =
      serviceContainer.resolveService<AuthService>('authService');

    expect(testService).toBeInstanceOf(TestService);
    expect(authService).toBeInstanceOf(AuthService);
  });

  test('should resolve service is not found', () => {
    const serviceName = 'testService2';
    // toThrow 를 테스트는 expect 첫번째 인자를 함수로 줘야함
    expect(() => {
      serviceContainer.resolveService(serviceName);
    }).toThrow(`Service ${serviceName} not found`);
  });

  test('should set and clear token correctly', async () => {
    const mockService = {
      setToken: jest.fn(),
    };

    serviceContainer.registerServiceBase('mockService', mockService);

    await serviceContainer.setToken('test-token');
    expect(mockService.setToken).toHaveBeenCalledWith('test-token');

    await serviceContainer.clearToken();
    expect(mockService.setToken).toHaveBeenCalledWith(null);
  });
});
