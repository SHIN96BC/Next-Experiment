import { AuthLoginReq } from '@Src/services/auth/model';
import serviceContainer from '@Src/services/ServiceContainer';
import AuthService from '@Src/services/auth/AuthService';

const queryKeys = {};

const queryOptions = {
  login: () => ({
    mutationFn: (data: AuthLoginReq) =>
      serviceContainer.resolveService<AuthService>('authService').login(data),
  }),
  logout: () => ({
    mutationFn: () =>
      serviceContainer.resolveService<AuthService>('authService').logout(),
  }),
};

export default queryOptions;
