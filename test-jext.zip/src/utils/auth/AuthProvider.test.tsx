import { setAuth } from '@Src/lib/features/auth/authSlice';
import CustomLocalStorage from '@Src/utils/storages/CustomLocalStorage';
import serviceContainer from '@Src/services/ServiceContainer';
import { render, testStoreCreate } from '@Src/jestUtils.test';
import { getServerSession } from 'next-auth';

// jest.mock('next-auth/react', () => {
//   const originalModule = jest.requireActual('next-auth/react');
//   const mockSession = {
//     accessToken: 'testToken',
//     expires: new Date(Date.now() + 2 * 86400).toISOString(),
//     user: { id: '123432343', name: '홍길동', email: 'test@test.com' },
//   };
//   return {
//     __esModule: true,
//     ...originalModule,
//     useSession: jest.fn(() => {
//       return { data: mockSession, status: 'authenticated', update: jest.fn() }; // return type is [] in v3 but changed to {} in v4
//     }),
//   };
// });
//
// jest.mock('next-auth', () => ({
//   getServerSession: jest.fn(),
// }));

describe('AuthProvider', () => {
  it('Should set the correct provider', () => {
    const mockSetToken = jest.spyOn(serviceContainer, 'setToken'); // setToken을 spy로 만듭니다.

    render(<div>Child Component</div>, {
      session: {
        accessToken: 'testToken',
        refreshToken: '',
        expires: new Date(Date.now() + 2 * 86400).toISOString(),
        user: {
          id: '123432343',
          name: '홍길동',
          email: 'test@test.com',
          image: '',
        },
      },
    });

    // serviceContainer.setToken이 호출되었는지 확인
    expect(mockSetToken).toHaveBeenLastCalledWith('testToken');
  });
});
