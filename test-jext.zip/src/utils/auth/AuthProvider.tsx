'use client';

import { ReactNode, useEffect } from 'react';
import serviceContainer from '@Src/services/ServiceContainer';
import { Session } from 'next-auth';
import { SessionProvider } from 'next-auth/react';

/**
 * Auth Provider
 * @param session
 * @param {React.ReactNode} children
 * @returns {React.ReactNode}
 * @constructor
 */
export default function AuthProvider({
  session,
  children,
}: {
  session: Session | null;
  children: ReactNode;
}): ReactNode {
  useEffect(() => {
    if (session && session.accessToken) {
      serviceContainer.setToken(session.accessToken);
    }
  }, [session]);

  console.log('session = ', session);

  return <SessionProvider session={session}>{children}</SessionProvider>;
}
